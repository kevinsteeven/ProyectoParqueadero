# Configuración inicial
AZURE_ENDPOINT = "https://proyectoclasificacion-prediction.cognitiveservices.azure.com/customvision/v3.0/Prediction/f0fa1701-a191-44cc-92dc-be952b7faecc/classify/iterations/ClasificadorVehiculos/image"
PREDICTION_KEY = "96L74RHpJHFp0VJ3pmgFkeozna1RnNwKebBjKCHYwWnY0qaPwgwWJQQJ99AKACLArgHXJ3w3AAAIACOG0EM6"

# Configuración de cupos
CUPOS_INICIALES_CARROS = 0
CUPOS_INICIALES_MOTOS = 0